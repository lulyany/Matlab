function plotting(size)
    axis((-size/2),(size/2),(-size/2),(size/2));
    ball.x=0;
    ball.y=0;
    plot(ball.x,ball.y,'bo','MarkerSize',10,'MarkerFaceColor','b');
end