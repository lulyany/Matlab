RGB = imread('ngc6543a.jpg');
image(RGB);