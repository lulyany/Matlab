function testing=testing(size)
    if ball.x = (-size/2) || ball.x=(size/2) || ball.y=(-size/2) || ball.y=(size/2)
       testing=1;
    else
        testing=0;
    end
end