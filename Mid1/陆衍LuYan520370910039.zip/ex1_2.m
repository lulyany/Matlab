function inputting()
    size=input('the length of one size of the square:');
    %the size of the square
    maxtimes=input('how many times the ball should bounce before stopping:');
    %how many times the ball should bounce before stopping
end
